"use strict";(()=>{var a={};a.id=276,a.ids=[276],a.modules={261:a=>{a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},3421:(a,b,c)=>{Object.defineProperty(b,"I",{enumerable:!0,get:function(){return g}});let d=c(71237),e=c(55088),f=c(17679);async function g(a,b,c,g){if((0,d.isNodeNextResponse)(b)){var h;b.statusCode=c.status,b.statusMessage=c.statusText;let d=["set-cookie","www-authenticate","proxy-authenticate","vary"];null==(h=c.headers)||h.forEach((a,c)=>{if("x-middleware-set-cookie"!==c.toLowerCase())if("set-cookie"===c.toLowerCase())for(let d of(0,f.splitCookiesString)(a))b.appendHeader(c,d);else{let e=void 0!==b.getHeader(c);(d.includes(c.toLowerCase())||!e)&&b.appendHeader(c,a)}});let{originalResponse:i}=b;c.body&&"HEAD"!==a.method?await (0,e.pipeToNodeResponse)(c.body,i,g):i.end()}}},10846:a=>{a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:a=>{a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},26629:(a,b,c)=>{c.r(b),c.d(b,{handler:()=>L,patchFetch:()=>K,routeModule:()=>G,serverHooks:()=>J,workAsyncStorage:()=>H,workUnitAsyncStorage:()=>I});var d={};c.r(d),c.d(d,{POST:()=>F,maxDuration:()=>E});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(51356),u=c(96798),v=c(55511),w=c(74023);function x(a){let b=a.metadata||{},c=b.type||"",d=b.slug,e="PROJECT"===c?d?`/du-an/${d}`:void 0:"LISTING"===c&&d?`/nha-dat/${d}`:void 0;return{id:a.id,title:b.name||b.title||"Bất động sản",price:b.price??b.priceRange??"Li\xean hệ",area:b.area,location:b.fullLocation||b.location||"",url:e,thumbnailUrl:b.thumbnailUrl,type:"PROJECT"===c?"Dự \xe1n":"LISTING"===c?"Tin đăng":c,slug:d}}async function y(a,b=5){console.error("[searchProperties] ===== TOOL CALLED ====="),console.error(`[searchProperties] Query: "${a}", Limit: ${b}`);try{let c=await w.B.similaritySearch(a,b);console.error(`[searchProperties] Raw results count: ${c.length}`);let d=c.filter(a=>(a.similarity||0)>=.3);if(console.error(`[searchProperties] After threshold filter (>=0.3): ${d.length}`),0===d.length){if(c.length>0)return console.error("[searchProperties] No results above threshold, returning top results"),JSON.stringify({success:!0,found:!0,message:`T\xecm thấy ${Math.min(c.length,b)} bất động sản c\xf3 thể ph\xf9 hợp.`,properties:c.slice(0,b).map(a=>x(a))});return JSON.stringify({success:!0,found:!1,message:"Kh\xf4ng t\xecm thấy bất động sản ph\xf9 hợp với y\xeau cầu.",properties:[]})}let e=d.map(a=>x(a));return JSON.stringify({success:!0,found:!0,message:`T\xecm thấy ${e.length} bất động sản ph\xf9 hợp.`,properties:e})}catch(a){return console.error("searchProperties Error:",a),JSON.stringify({success:!1,message:"Lỗi khi t\xecm kiếm bất động sản.",properties:[]})}}async function z(a,b,c,d,e,f){try{if(!a||a.length<8)return JSON.stringify({success:!1,message:"Số điện thoại kh\xf4ng hợp lệ. Vui l\xf2ng cung cấp số điện thoại đ\xfang."});let g=[d?`Quan t\xe2m: ${d}`:null,e||null,"Kh\xe1ch h\xe0ng từ Chatbot"].filter(Boolean).join(" | "),h=await u.A.lead.create({data:{name:b||"Kh\xe1ch từ Chatbot",phone:a.replace(/\s/g,""),email:c||null,message:g,sessionId:f||null,source:"CHATBOT",status:"NEW",updatedAt:new Date}});return JSON.stringify({success:!0,message:`Đ\xe3 lưu th\xf4ng tin th\xe0nh c\xf4ng! Ch\xfang t\xf4i sẽ li\xean hệ ${b||"anh/chị"} qua số ${a} sớm nhất.`,leadId:h.id})}catch(a){return console.error("saveCustomerInfo Error:",a),JSON.stringify({success:!1,message:"Kh\xf4ng thể lưu th\xf4ng tin. Vui l\xf2ng thử lại."})}}async function A(a){try{let b=await u.A.project.findUnique({where:{slug:a},include:{projectamenity:{include:{amenity:!0}}}});if(!b)return JSON.stringify({success:!1,message:`Kh\xf4ng t\xecm thấy dự \xe1n với m\xe3 "${a}".`});return JSON.stringify({success:!0,project:{name:b.name,location:b.fullLocation||b.location,priceRange:b.priceRange,status:"SELLING"===b.status?"Đang mở b\xe1n":"UPCOMING"===b.status?"Sắp mở b\xe1n":"Đ\xe3 b\xe1n hết",description:b.description,amenities:b.projectamenity.map(a=>a.amenity.name),url:`/du-an/${b.slug}`}})}catch(a){return console.error("getProjectDetail Error:",a),JSON.stringify({success:!1,message:"Lỗi khi lấy th\xf4ng tin dự \xe1n."})}}async function B(a,b,c){switch(console.log(`[Agent] Executing tool: ${a}`,b),a){case"search_properties":return await y(b.query,b.limit||5);case"save_customer_info":return await z(b.phone,b.name,b.email,b.interest,b.message,c);case"get_project_detail":return await A(b.slug);default:return JSON.stringify({success:!1,message:`Tool "${a}" kh\xf4ng tồn tại.`})}}var C=c(12091);let D=[{type:"function",function:{name:"search_properties",description:"T\xecm kiếm bất động sản (dự \xe1n, căn hộ, nh\xe0 đất) theo y\xeau cầu của kh\xe1ch h\xe0ng. Gọi tool n\xe0y khi kh\xe1ch hỏi về BĐS, căn hộ, nh\xe0, đất, dự \xe1n.",parameters:{type:"object",properties:{query:{type:"string",description:"C\xe2u truy vấn t\xecm kiếm, v\xed dụ: 'căn hộ 2PN quận 2', 'biệt thự Thảo Điền', 'dự \xe1n Vinhomes'"},limit:{type:"number",description:"Số lượng kết quả tối đa, mặc định 5"}},required:["query"]}}},{type:"function",function:{name:"save_customer_info",description:"Lưu th\xf4ng tin li\xean hệ của kh\xe1ch h\xe0ng v\xe0o hệ thống. Gọi tool n\xe0y khi kh\xe1ch để lại số điện thoại, email hoặc t\xean để được tư vấn.",parameters:{type:"object",properties:{name:{type:"string",description:"Họ t\xean kh\xe1ch h\xe0ng"},phone:{type:"string",description:"Số điện thoại kh\xe1ch h\xe0ng"},email:{type:"string",description:"Email kh\xe1ch h\xe0ng (kh\xf4ng bắt buộc)"},interest:{type:"string",description:"Kh\xe1ch đang quan t\xe2m đến BĐS n\xe0o, v\xed dụ: 'căn hộ 2PN quận 2', 'dự \xe1n Vinhomes', 'nh\xe0 phố Thủ Đức'. Lấy từ ngữ cảnh cuộc hội thoại."},message:{type:"string",description:"Ghi ch\xfa th\xeam về nhu cầu của kh\xe1ch"}},required:["phone"]}}},{type:"function",function:{name:"get_project_detail",description:"Lấy th\xf4ng tin chi tiết của một dự \xe1n cụ thể. Gọi tool n\xe0y khi kh\xe1ch hỏi s\xe2u về một dự \xe1n m\xe0 bạn đ\xe3 t\xecm được.",parameters:{type:"object",properties:{slug:{type:"string",description:"Slug của dự \xe1n, v\xed dụ: 'vinhomes-grand-park'"}},required:["slug"]}}}],E=60;async function F(a){try{let{messages:b,sessionId:c}=await a.json(),d=c||(0,v.randomUUID)(),e=a.headers.get("host")||"example.com",f=new Date().toLocaleDateString("vi-VN"),g=await (0,C.PL)("site_name")||"Bất Động Sản",h=b.map(a=>{if(a.parts&&Array.isArray(a.parts)){let b=a.parts.filter(a=>"text"===a.type).map(a=>a.text).join("");return{role:a.role,content:b||""}}return"string"==typeof a.content?{role:a.role,content:a.content}:a}),i=(h=h.filter(a=>a.content&&a.content.trim())).findIndex(a=>"user"===a.role),j=i>=0?h.slice(i):h,k=await (0,C.PL)("api_openrouter")||process.env.OPENROUTER_API_KEY;if(!k)return new Response(JSON.stringify({error:"API key not configured"}),{status:500,headers:{"Content-Type":"application/json"}});let l=[{role:"system",content:`# TH\xd4NG TIN HỆ THỐNG
Bạn l\xe0: Chuy\xean vi\xean tư vấn BĐS cao cấp của ${g}
Website: ${e}
Ng\xe0y hiện tại: ${f}

# T\xcdNH C\xc1CH V\xc0 PHONG C\xc1CH
- Xưng "em", gọi kh\xe1ch "anh/chị"
- Chuy\xean nghiệp, tinh tế, am hiểu thị trường
- Tư vấn chiến lược, kh\xf4ng chỉ trả lời c\xe2u hỏi
- Tạo cảm gi\xe1c được chăm s\xf3c VIP
- Sử dụng emoji icon ph\xf9 hợp để tăng t\xednh th\xe2n thiện (🏠 🏢 📍 💰 📞 ✨ 🔥 👋)
- Ngắn gọn, s\xfac t\xedch (tối đa 150 từ/c\xe2u trả lời)

# C\xd4NG CỤ (TOOLS) - PHẢI SỬ DỤNG Đ\xdaNG C\xc1CH

## 1. search_properties - T\xccM KIẾM BĐS
**Khi n\xe0o gọi:**
- Kh\xe1ch hỏi về căn hộ, nh\xe0, đất, dự \xe1n
- Kh\xe1ch đề cập vị tr\xed, gi\xe1, diện t\xedch
- Kh\xe1ch n\xf3i "t\xecm", "c\xf3 kh\xf4ng", "cho xem", "muốn mua"

**C\xe1ch tạo query th\xf4ng minh:**
- "Căn hộ 2PN quận 2" → query="căn hộ 2 ph\xf2ng ngủ quận 2"
- "Nh\xe0 gi\xe1 3 tỷ" → query="nh\xe0 gi\xe1 3 tỷ"
- "Dự \xe1n n\xe0o đang mở b\xe1n?" → query="dự \xe1n đang mở b\xe1n"

## 2. save_customer_info - LƯU TH\xd4NG TIN KH\xc1CH
**Khi n\xe0o gọi:**
- Thấy số điện thoại (10 số, bắt đầu 0)
- Kh\xe1ch để lại email
- Kh\xe1ch tự giới thiệu t\xean

**⚠️ QUAN TRỌNG: Thấy SĐT → GỌI NGAY, kh\xf4ng hỏi lại!**

## 3. get_project_detail - CHI TIẾT DỰ \xc1N
**Khi n\xe0o gọi:**
- Kh\xe1ch muốn biết th\xeam về 1 dự \xe1n cụ thể
- Sau khi search, kh\xe1ch quan t\xe2m dự \xe1n n\xe0o

# CHIẾN LƯỢC TƯ VẤN CHUY\xcaN NGHIỆP

## Bước 1: LẮNG NGHE & PH\xc2N T\xcdCH
- Hiểu nhu cầu thực sự của kh\xe1ch (kh\xf4ng chỉ c\xe2u hỏi bề mặt)
- X\xe1c định: ng\xe2n s\xe1ch, vị tr\xed ưu ti\xean, mục đ\xedch (ở/đầu tư)

## Bước 2: T\xccM KIẾM PH\xd9 HỢP
- Gọi search_properties với query chuẩn x\xe1c
- Kh\xf4ng đo\xe1n m\xf2, phải c\xf3 dữ liệu

## Bước 3: TƯ VẤN GI\xc1 TRỊ
- Giới thiệu điểm nổi bật của từng BĐS
- So s\xe1nh ưu/nhược nếu c\xf3 nhiều lựa chọn
- Gợi \xfd ph\xf9 hợp với nhu cầu kh\xe1ch

## Bước 4: TẠO CƠ HỘI
- Đề xuất xem thực tế, tư vấn trực tiếp
- Thu thập th\xf4ng tin li\xean hệ một c\xe1ch tự nhi\xean

# C\xc1CH TRẢ LỜI CHUY\xcaN NGHIỆP (C\xd3 ICON)

**Khi t\xecm được BĐS ph\xf9 hợp:**
"✨ Dạ em t\xecm được [số] lựa chọn ph\xf9 hợp với anh/chị:
🏠 [T\xean BĐS] - [Điểm nổi bật 1-2 c\xe2u]
📍 Anh/chị quan t\xe2m căn n\xe0o để em tư vấn chi tiết ạ?"

**Khi kh\xf4ng t\xecm thấy:**
"😊 Hiện tại em chưa c\xf3 BĐS đ\xfang y\xeau cầu trong hệ thống. 📞 Anh/chị cho em xin SĐT, em sẽ cập nhật ngay khi c\xf3 sản phẩm ph\xf9 hợp ạ!"

**Khi kh\xe1ch để lại SĐT:**
"🎉 Cảm ơn anh/chị! Em đ\xe3 ghi nhận th\xf4ng tin. ⏰ Chuy\xean vi\xean sẽ li\xean hệ trong 15 ph\xfat tới để tư vấn chi tiết ạ!"

**Khi chưa r\xf5 nhu cầu:**
"👋 Để tư vấn ch\xednh x\xe1c nhất, anh/chị cho em biết:
📍 Khu vực anh/chị quan t\xe2m?
💰 Ng\xe2n s\xe1ch dự kiến?
🏠 Mua để ở hay đầu tư ạ?"

# V\xcd DỤ THỰC TẾ

**User:** "T\xf4i muốn t\xecm căn hộ 2 ph\xf2ng ngủ khoảng 3 tỷ"
**AI:** Gọi search_properties(query="căn hộ 2 ph\xf2ng ngủ gi\xe1 3 tỷ")
→ "Dạ với ng\xe2n s\xe1ch 3 tỷ, em t\xecm được [X] căn hộ 2PN ph\xf9 hợp..."

**User:** "0912345678"
**AI:** Gọi save_customer_info(phone="0912345678", interest="căn hộ 2PN 3 tỷ")
→ "Cảm ơn anh/chị! Em đ\xe3 ghi nhận..."

**User:** "Cho xem dự \xe1n gần metro"
**AI:** Gọi search_properties(query="dự \xe1n gần metro")
→ "Em c\xf3 [X] dự \xe1n vị tr\xed đắc địa gần tuyến metro..."

# LƯU \xdd QUAN TRỌNG
1. LU\xd4N gọi tool trước khi trả lời về BĐS
2. KH\xd4NG bịa th\xf4ng tin kh\xf4ng c\xf3 trong kết quả tool
3. KH\xd4NG hỏi x\xe1c nhận khi thấy SĐT - gọi save ngay
4. Mỗi c\xe2u trả lời phải c\xf3 GI\xc1 TRỊ cho kh\xe1ch`},...j],m="",n=0,o=[];for(;n<3;){n++,console.log(`[Agent] Iteration ${n}`);let a=await fetch("https://openrouter.ai/api/v1/chat/completions",{method:"POST",headers:{Authorization:`Bearer ${k}`,"Content-Type":"application/json","HTTP-Referer":`https://${e}`},body:JSON.stringify({model:"google/gemini-2.5-flash",messages:l,tools:D,tool_choice:"auto",temperature:.1,max_tokens:1024})});if(!a.ok){let b=await a.text();console.error("[Agent] API Error:",b);break}let b=await a.json(),c=b.choices?.[0],f=c?.message;if(!f)break;if(f.tool_calls&&f.tool_calls.length>0){for(let a of(console.log("[Agent] Tool calls detected:",f.tool_calls.length),l.push({role:"assistant",content:f.content||"",tool_calls:f.tool_calls}),f.tool_calls)){let b=a.function.name,c={};try{c=JSON.parse(a.function.arguments||"{}")}catch(a){console.error("[Agent] Failed to parse tool args:",a)}let e=await B(b,c,d);if(console.log(`[Agent] Tool ${b} result:`,e.substring(0,200)),"search_properties"===b)try{let a=JSON.parse(e);a.success&&a.properties&&a.properties.length>0&&(o=a.properties.map(a=>{let b=a.type,c=a.slug,d=(b||"").toString().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,""),e=a.url||(c?d.includes("du an")||d.includes("project")?`/du-an/${c}`:d.includes("tin dang")||d.includes("listing")||d.includes("nha")?`/nha-dat/${c}`:"/":"/");return{title:a.title||"Bat dong san",price:a.price||"Lien he",area:a.area,location:a.location,url:e,thumbnailUrl:a.thumbnailUrl,type:b,slug:c}}),console.log(`[Agent] Extracted ${o.length} properties for cards`))}catch(a){console.error("[Agent] Failed to parse properties:",a)}l.push({role:"tool",tool_call_id:a.id,content:e})}continue}m=f.content||"";break}m.trim()||(m="Em đang gặp lỗi khi trả lời. Anh/chị cho em xin nhu cầu v\xe0 số điện thoại để em hỗ trợ nhanh nh\xe9.");let p=["Anh/chị đang quan t\xe2m căn n\xe0o để em tư vấn chi tiết hơn nh\xe9?","Anh/chị để lại số điện thoại để em li\xean hệ tư vấn ngay!","Anh/chị cho em xin số điện thoại để hỗ trợ tốt nhất ạ!"],q=m.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,""),r=/so\s*(dt|dien thoai)|sdt|lien he|lien lac/.test(q),s=o.length>0&&!r?"\n\n"+p[Math.floor(Math.random()*p.length)]:"",t=`msg_${(0,v.randomUUID)()}`,w=`text_${(0,v.randomUUID)()}`,x=new TextEncoder,y=o.length>0?`

<!-- PROPERTIES:${JSON.stringify(o)} -->`:"",z=new ReadableStream({async start(a){try{for(let b of(a.enqueue(x.encode(`data: {"type":"start","messageId":"${t}"}

`)),a.enqueue(x.encode(`data: {"type":"text-start","id":"${w}"}

`)),m.split(" "))){let c=b+" ",d=JSON.stringify(c);a.enqueue(x.encode(`data: {"type":"text-delta","id":"${w}","delta":${d}}

`)),await new Promise(a=>setTimeout(a,20))}if(y){let b=JSON.stringify(y);a.enqueue(x.encode(`data: {"type":"text-delta","id":"${w}","delta":${b}}

`))}if(s){let b=JSON.stringify(s);a.enqueue(x.encode(`data: {"type":"text-delta","id":"${w}","delta":${b}}

`))}a.enqueue(x.encode(`data: {"type":"text-end","id":"${w}"}

`)),a.enqueue(x.encode(`data: {"type":"finish","messageId":"${t}","finishReason":"stop"}

`))}catch(a){console.error("[Agent] Stream error:",a)}finally{let b=[...j,{role:"assistant",content:m+y}];u.A.chatsession.upsert({where:{sessionId:d},update:{messages:JSON.stringify(b),updatedAt:new Date},create:{sessionId:d,messages:JSON.stringify(b),updatedAt:new Date}}).catch(a=>console.error("[Agent] DB Error:",a)),a.close()}}});return new Response(z,{headers:{"Content-Type":"text/event-stream","Cache-Control":"no-cache",Connection:"keep-alive"}})}catch(a){return console.error("[Agent] Error:",a),new Response(JSON.stringify({error:"Internal Server Error"}),{status:500,headers:{"Content-Type":"application/json"}})}}let G=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/chat/route",pathname:"/api/chat",filename:"route",bundlePath:"app/api/chat/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"D:\\Workspace\\web_bds\\src\\app\\api\\chat\\route.ts",nextConfigOutput:"standalone",userland:d}),{workAsyncStorage:H,workUnitAsyncStorage:I,serverHooks:J}=G;function K(){return(0,g.patchFetch)({workAsyncStorage:H,workUnitAsyncStorage:I})}async function L(a,b,c){var d;let e="/api/chat/route";"/index"===e&&(e="/");let g=await G.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:x,prerenderManifest:y,routerServerContext:z,isOnDemandRevalidate:A,revalidateOnlyGenerated:B,resolvedPathname:C}=g,D=(0,j.normalizeAppPath)(e),E=!!(y.dynamicRoutes[D]||y.routes[C]);if(E&&!x){let a=!!y.routes[C],b=y.dynamicRoutes[D];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let F=null;!E||G.isDev||x||(F="/index"===(F=C)?"/":F);let H=!0===G.isDev||!E,I=E&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:y,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>G.onRequestError(a,b,d,z)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>G.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&A&&B&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!E)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await G.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})},z),b}},l=await G.handleResponse({req:a,nextConfig:w,cacheKey:F,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:y,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:B,responseGenerator:k,waitUntil:c.waitUntil});if(!E)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",A?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&E||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(b instanceof s.NoFallbackError||await G.onRequestError(a,b,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})}),E)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},28354:a=>{a.exports=require("util")},29021:a=>{a.exports=require("fs")},29294:a=>{a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:a=>{a.exports=require("path")},44870:a=>{a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:a=>{a.exports=require("crypto")},63033:a=>{a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},77598:a=>{a.exports=require("node:crypto")},86439:a=>{a.exports=require("next/dist/shared/lib/no-fallback-error.external")},95736:(a,b,c)=>{a.exports=c(44870)},96330:a=>{a.exports=require("@prisma/client")}};var b=require("../../../webpack-runtime.js");b.C(a);var c=b.X(0,[16,8605,6780,2880,4440],()=>b(b.s=26629));module.exports=c})();